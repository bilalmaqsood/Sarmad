<div class="renamer-tool">

	<div class="renamer-tool__overlay" data-renamer-tool-cancel></div>

	<div class="renamer-tool__box">

		<label>Type in the name of this room:</label>
		<input data-name-input type="text" value="">

		<div class="renamer-tool__buttons">
			<button class="btn btn-primary small" data-renamer-tool-cancel>Cancel</button>
			<button class="btn btn-primary small green" data-renamer-tool-save>Done</button>
		</div>
	</div>


</div>